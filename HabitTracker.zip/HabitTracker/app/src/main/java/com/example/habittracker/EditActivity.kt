package com.example.habittracker

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class EditActivity: AppCompatActivity()  {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.add_form)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.l_add_form)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val habitName = intent.getStringExtra("habit_name")
        val habitDis = intent.getStringExtra("habit_dis")

        val tfName = findViewById<EditText>(R.id.habitName)
        val tfDis = findViewById<EditText>(R.id.discHabit)

        tfName.setText(habitName)
        tfDis.setText(habitDis)

        val editBtn = findViewById<Button>(R.id.saveHabitBtn)
        editBtn.setOnClickListener {
           val newName = tfName.text.toString()
           val newDisc =  tfDis.text.toString()
            intent.putExtra("newName", newName)
            intent.putExtra("newDisc", newDisc)
            setResult(Activity.RESULT_OK, intent)
            finish()
        }
    }
}