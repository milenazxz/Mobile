package com.example.habittracker
import java.util.Date
import java.io.Serializable

data class Habit(
    var name: String,
    var isDone: Boolean,
    var dis: String?,
    var createdDate: Date = Date(),
    var completionDates: MutableList<Long> = mutableListOf()
) : Serializable