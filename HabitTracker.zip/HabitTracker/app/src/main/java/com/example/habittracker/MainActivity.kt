package com.example.habittracker

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlarmManager.RTC_WAKEUP
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.content.Context
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.ListView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationManagerCompat
import android.content.pm.PackageManager
import android.net.Uri
import java.util.Calendar
import android.os.Build
import android.provider.Settings
import android.widget.ImageButton
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import java.time.LocalDate
import java.time.ZoneId

class MainActivity : AppCompatActivity() {

    var habits = mutableListOf<Habit>()
    var selectedPosition = -1
    var js = JsonSave();

    companion object {
        const val CHANNEL_ID = "Not3"
        const val NOTIFICATION_ID = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            }
        }

        createNotificationChannel()
        scheduleMidnightResetAlarm()

        habits = js.loadHabits(this)

        val listHabit: ListView = findViewById(R.id.list_item)

        val adapter = object: ArrayAdapter<Habit>(this, R.layout.list_item, R.id.textViewHabit, habits){
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val view = convertView ?: layoutInflater.inflate(R.layout.list_item, parent, false)

                val textView = view.findViewById<TextView>(R.id.textViewHabit)
                val checkBox = view.findViewById<CheckBox>(R.id.checkBoxHabit)
                val curHabit: Habit = habits[position]

                textView.text = curHabit.name

                checkBox.setOnCheckedChangeListener(null)
                checkBox.isChecked = curHabit.completionDates.contains(getStartOfDay())

                checkBox.setOnCheckedChangeListener { _, isChecked ->
                    val todayStart = getStartOfDay()

                    if (isChecked) {
                        if (!curHabit.completionDates.contains(todayStart)) {
                            curHabit.completionDates.add(todayStart)
                        }
                    } else {
                        curHabit.completionDates.remove(todayStart)
                    }

                    js.saveHabits(this@MainActivity, habits, "habits_json")
                }
                if (position == selectedPosition) {
                    view.setBackgroundColor(Color.BLUE)
                } else {
                    view.setBackgroundColor(Color.TRANSPARENT)
                }
                return view
            }
        }
        listHabit.adapter = adapter


        listHabit.setOnItemClickListener { _, _, position, _ ->
            selectedPosition = position
            adapter.notifyDataSetChanged()
        }


        val launcher1: ActivityResultLauncher<Intent>
        launcher1 = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val habitName = result.data?.getStringExtra("habit_name")
                val habitDisc = result.data?.getStringExtra("habit_disc")
                if (!habitName.isNullOrEmpty()) {
                    habits.add(Habit(habitName, false, habitDisc))
                    js.saveHabits(this, habits, "habits_json")
                    adapter.notifyDataSetChanged()
                }
            }
        }
        val launcher2: ActivityResultLauncher<Intent>
        launcher2 = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val habitName = result.data?.getStringExtra("newName")
                val habitDisc = result.data?.getStringExtra("newDisc")
                if (!habitName.isNullOrEmpty()) {
                    habits[selectedPosition].name = habitName
                    habits[selectedPosition].dis = habitDisc
                    js.saveHabits(this, habits, "habits_json")
                    adapter.notifyDataSetChanged()
                }
            }
        }


        val addBtn: Button = findViewById(R.id.add_btn)
        val deliteBtn: Button = findViewById(R.id.delite_btn)
        val editBtn: Button = findViewById(R.id.edit_btn)
        val statBtn: Button = findViewById(R.id.stat_btn)
        val NotifSettingBtn: ImageButton = findViewById(R.id.notifSetBtn)


        addBtn.setOnClickListener {
            val intent: Intent = Intent(this, AddActivity::class.java)
            launcher1.launch(intent)
        }
        deliteBtn.setOnClickListener {
            habits.removeAt(selectedPosition)
            js.saveHabits(this, habits, "habits_json")
            adapter.notifyDataSetChanged()
        }
        editBtn.setOnClickListener {
            val intent: Intent = Intent(this, EditActivity::class.java)
            intent.putExtra("habit_name", habits[selectedPosition].name)
            intent.putExtra("habit_dis", habits[selectedPosition].dis)
            launcher2.launch(intent)
        }
        statBtn.setOnClickListener {
            val intent: Intent = Intent(this, StatActivity::class.java)
            launcher1.launch(intent)
        }
        NotifSettingBtn.setOnClickListener {
            showTimePicker()
        }

    }

    private fun getStartOfDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
    private fun scheduleMidnightResetAlarm() {
        val alarmManager = getSystemService(AlarmManager::class.java)
        val intent = Intent(this, StartNewDayReceiver::class.java).apply {
            action = "com.example.habittracker.ACTION_MIDNIGHT_RESET"
        }

        val pendingIntent = PendingIntent.getBroadcast(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        // Устанавливаем точный будильник, если возможно
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            } else {
                // Можно показать диалог или использовать менее точный режим
                alarmManager.setWindow(RTC_WAKEUP, calendar.timeInMillis, 10 * 60 * 1000, pendingIntent)
            }
        } else {
            alarmManager.setExactAndAllowWhileIdle(RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Habit Reminder",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Ежедневные напоминания о привычках"
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        TimePickerDialog(
            this,
            { _, selectedHour, selectedMinute ->
                saveReminderTime(selectedHour, selectedMinute)
                scheduleDailyReminder(selectedHour, selectedMinute)
                Toast.makeText(
                    this,
                    "Напоминание установлено на ${
                        String.format(
                            "%02d:%02d",
                            selectedHour,
                            selectedMinute
                        )
                    }",
                    Toast.LENGTH_SHORT
                ).show()
            },
            hour,
            minute,
            true
        ).show()
    }

    private fun saveReminderTime(hour: Int, minute: Int) {
        getSharedPreferences("settings", Context.MODE_PRIVATE).edit()
            .putInt("reminder_hour", hour)
            .putInt("reminder_minute", minute)
            .apply()
    }

    private fun scheduleDailyReminder(hour: Int, minute: Int) {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        val alarmManager = getSystemService(AlarmManager::class.java)
        val intent = Intent(this, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this,
            NOTIFICATION_ID,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
                } else {
                    alarmManager.setWindow(
                        AlarmManager.RTC_WAKEUP,
                        calendar.timeInMillis,
                        15 * 60 * 1000, // окно ±15 минут
                        pendingIntent
                    )
                    showExactAlarmPermissionDialog()
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            } else {
                alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, "Не удалось установить напоминание", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showExactAlarmPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Требуется разрешение")
            .setMessage("Чтобы напоминания приходили точно вовремя, разрешите приложению устанавливать точные будильники.")
            .setPositiveButton("Перейти в настройки") { _, _ ->
                val intent = Intent().apply {
                    action = Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
                    data = Uri.fromParts("package", packageName, null)
                }
                try {
                    startActivity(intent)
                } catch (e: ActivityNotFoundException) {
                    Toast.makeText(this, "Не удалось открыть настройки", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

}