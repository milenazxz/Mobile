package com.example.habittracker

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Calendar
import java.util.Date

class StatActivity : AppCompatActivity() {

    private lateinit var habits: MutableList<Habit>
    private lateinit var js: JsonSave

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stat)

        // --- Загрузка привычек ---
        js = JsonSave()
        habits = js.loadHabits(this)

        // --- Views ---
        val totalHabitsTv: TextView = findViewById(R.id.totalHabits)
        val doneHabitsTv: TextView = findViewById(R.id.doneHabits)
        val pendingHabitsTv: TextView = findViewById(R.id.pendingHabits)
        val completionRateTv: TextView = findViewById(R.id.completionRate)
        val streakTv: TextView = findViewById(R.id.streak)
        val weekChart: BarChartView = findViewById(R.id.weekChart)
        val topList: ListView = findViewById(R.id.topHabitsList)

        // --- Основные показатели ---
        val total = habits.size
        val doneToday = habits.count { isHabitDoneToday(it) }
        val pending = total - doneToday
        val completionRate = if (total > 0) (doneToday * 100) / total else 0

        totalHabitsTv.text = "Всего привычек: $total"
        doneHabitsTv.text = "Выполнено сегодня: $doneToday"
        pendingHabitsTv.text = "Осталось выполнить: $pending"
        completionRateTv.text = "Процент выполнения: $completionRate%"

        // --- Серия выполнения ---
        val todayCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        var streak = 0
        val today = getStartOfDay()

        for (i in 0..365) {
            val day = today - i * 24 * 60 * 60 * 1000L
            val anyDone = habits.any { it.completionDates.contains(day) }

            if (anyDone) {
                streak++
            } else {
                break
            }
        }

        streakTv.text = "Текущая серия дней: $streak"

        // --- Данные для графика за последние 7 дней ---
        val todayStart = getStartOfDay()
        val last7Days = (0..6).map { i ->
            todayStart - i * 24 * 60 * 60 * 1000L // вычитаем i дней в миллисекундах
        }.reversed()

        val shortDays = listOf("Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс")

        val weekData = last7Days.map { dayInMillis ->
            val completedCount = habits.count { habit ->
                habit.completionDates.contains(dayInMillis)
            }
            completedCount.toFloat()
        }

        val weekLabels = last7Days.map { dayInMillis ->
            val dayOfWeek = Calendar.getInstance().apply { timeInMillis = dayInMillis }.get(Calendar.DAY_OF_WEEK)
            shortDays[(dayOfWeek + 5) % 7]
        }

        weekChart.setData(weekData, weekLabels)

        // --- Топ привычек (по выполнению) ---
        val topHabits = habits.sortedByDescending { if (isHabitDoneToday(it)) 1 else 0 }.take(5)
        val adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            topHabits.map { "${it.name} (${if (isHabitDoneToday(it)) "✔" else "✘"})" }
        )
        topList.adapter = adapter

    }

    private fun getStartOfDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
    private fun isHabitDoneToday(habit: Habit): Boolean {
        return habit.completionDates.contains(getStartOfDay())
    }
}
