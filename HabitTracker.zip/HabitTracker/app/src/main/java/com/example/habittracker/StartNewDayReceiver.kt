package com.example.habittracker

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Date

class StartNewDayReceiver: BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == "com.example.habittracker.ACTION_MIDNIGHT_RESET") {
            val js = JsonSave()
            val habits = js.loadHabits(context)

            for (habit in habits) {
                habit.isDone = false
            }

            js.saveHabits(context, habits, "habits_prefs")
        }
    }

}