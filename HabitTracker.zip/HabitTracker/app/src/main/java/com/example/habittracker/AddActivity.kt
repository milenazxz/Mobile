package com.example.habittracker

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class AddActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.add_form)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.l_add_form)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val tfNameHabit = findViewById<EditText>(R.id.habitName)
        val tfDiscHabit = findViewById<EditText>(R.id.discHabit)
        val saveBtn = findViewById<Button>(R.id.saveHabitBtn)

        saveBtn.setOnClickListener {
            val habitName = tfNameHabit.text.toString()
            val habitDisc = tfDiscHabit.text.toString()

            if (habitName.isNotEmpty()) {
                val intent = Intent()
                intent.putExtra("habit_name", habitName)
                intent.putExtra("habit_disc", habitDisc)
                setResult(Activity.RESULT_OK, intent)
                finish()
            } else {
                tfNameHabit.error = "Введите название привычки"
            }
        }
    }
}