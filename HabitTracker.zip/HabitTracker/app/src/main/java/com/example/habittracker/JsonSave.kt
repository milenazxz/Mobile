package com.example.habittracker

import android.content.Context
import android.content.Context.MODE_PRIVATE
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class JsonSave {
    fun saveHabits(context: Context, habits: List<Habit>, name: String) {
        val prefs = context.getSharedPreferences("habits_prefs", MODE_PRIVATE)
        val gson = Gson()
        val json = gson.toJson(habits)

        prefs.edit()
            .putString(name, json)
            .apply()
    }
    fun loadHabits(context: Context): MutableList<Habit> {
        val prefs = context.getSharedPreferences("habits_prefs", MODE_PRIVATE)
        val json = prefs.getString("habits_json", null) ?: return mutableListOf()

        val type = object : TypeToken<MutableList<Habit>>() {}.type
        return Gson().fromJson(json, type)
    }

}