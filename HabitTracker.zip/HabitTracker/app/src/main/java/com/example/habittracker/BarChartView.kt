package com.example.habittracker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View

class BarChartView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLUE
    }

    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        strokeWidth = 4f
    }

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        textSize = 32f
        textAlign = Paint.Align.CENTER
    }

    private var data: List<Float> = emptyList()
    private var labels: List<String> = emptyList()

    fun setData(values: List<Float>, labels: List<String>) {
        require(values.size == labels.size) { "Data and labels must have the same size" }
        this.data = values
        this.labels = labels
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (data.isEmpty()) return

        // Отступы
        val padding = 40f
        val labelHeight = 40f
        val chartAreaTop = padding
        val chartAreaBottom = height - padding - labelHeight
        val chartAreaLeft = padding
        val chartAreaRight = width - padding

        val chartWidth = chartAreaRight - chartAreaLeft
        val chartHeight = chartAreaBottom - chartAreaTop

        val maxVal = data.maxOrNull() ?: 1f
        val barWidth = chartWidth / data.size

        // === Рисуем ось Y (вертикальная) ===
        canvas.drawLine(chartAreaLeft, chartAreaTop, chartAreaLeft, chartAreaBottom, axisPaint)

        // === Рисуем ось X (горизонтальная) ===
        canvas.drawLine(chartAreaLeft, chartAreaBottom, chartAreaRight, chartAreaBottom, axisPaint)

        // === Рисуем столбцы и подписи X ===
        for ((index, value) in data.withIndex()) {
            val x = chartAreaLeft + index * barWidth + barWidth / 2
            val barHeight = (value / maxVal) * chartHeight
            val top = chartAreaBottom - barHeight
            val bottom = chartAreaBottom
            val halfBar = barWidth * 0.3f

            // Столбец
            canvas.drawRect(x - halfBar, top, x + halfBar, bottom, barPaint)

            // Подпись по X (под осью)
            canvas.drawText(labels[index], x, chartAreaBottom + labelHeight - 8f, textPaint)
        }

        // === (Опционально) Подписи по Y ===
        // Например, минимум (0) и максимум
        val textBounds = Rect()
        textPaint.getTextBounds("0", 0, 1, textBounds)
        val textOffset = textBounds.height().toFloat()

        // Подпись "0" внизу слева
        textPaint.textAlign = Paint.Align.LEFT
        canvas.drawText("0", chartAreaLeft + 8f, chartAreaBottom + textOffset, textPaint)

        // Подпись максимума вверху слева
        val maxLabel = maxVal.toInt().toString()
        canvas.drawText(maxLabel, chartAreaLeft + 8f, chartAreaTop + textOffset, textPaint)

        // Возвращаем выравнивание по центру (если понадобится позже)
        textPaint.textAlign = Paint.Align.CENTER
    }
}